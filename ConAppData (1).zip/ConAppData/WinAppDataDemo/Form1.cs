﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinAppDataDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void ShowData()
        {
           SqlConnection cn = new SqlConnection(@"Data Source=POOLW42SLPC6266;Initial Catalog=Fresher;Integrated Security=True");
           SqlCommand cmd = new SqlCommand("Select * From Employee", cn);
           SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ShowData();
            using (SqlConnection conn = new SqlConnection(@"Data Source=POOLW42SLPC6266;Initial Catalog=Fresher;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("Select * from Employee", conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();

                    DataTable dt = new DataTable(); 
                    dt.Load(reader);
                    dataGridView1.DataSource = dt;
                    
                    
                    
                }
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
