﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ConAppData
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (SqlConnection conn = new SqlConnection(@"Data Source=POOLW42SLPC6266;Initial Catalog=Fresher;Integrated Security=True"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("Select * from Employee", conn))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Console.WriteLine(reader[0]);
                        Console.WriteLine(reader[1]);
                        Console.WriteLine(reader[2]);
                    }
                    reader.Close();
                }
            }
        }
    }
}
