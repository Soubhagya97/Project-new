﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace ConAppData
{
    internal class AdoData
    {
        static void Main()
        {
            SqlConnection cn;
            SqlCommand cmd;
            SqlDataAdapter dataAdapter;
         //   DataSet ds;
            try
            {
                cn = new SqlConnection(@"Data Source=POOLW42SLPC6266;Initial Catalog=Fresher;Integrated Security=True");
                cmd = new SqlCommand("Select * From Employee", cn);
                dataAdapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                dataAdapter.Fill(ds);
                Console.WriteLine($"empId {ds.Tables[0].Rows[0][0]}");
                Console.WriteLine($"empName {ds.Tables[0].Rows[0][1]}");
                Console.WriteLine($"empSalary {ds.Tables[0].Rows[0][2]}");
                foreach (DataRow dataRow in ds.Tables[0].Rows)
                {
                    Console.WriteLine($"empId {dataRow[0]} {dataRow[1]} {dataRow[2]}");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {



            }
        }
    }
}

